package com.duckscale;

import android.graphics.SurfaceTexture;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.projection.MediaProjection;
import android.opengl.GLES11Ext;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.os.Process;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.util.Log;
import android.view.Surface;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class Renderer implements GLSurfaceView.Renderer {
    static final String TAG = "DuckScale";
    static final int BLK = 16;

    static final String VS =
            "#version 300 es\n" +
            "out vec2 vUv;\n" +
            "void main(){\n" +
            "  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n" +
            "  vUv = p;\n" +
            "  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n" +
            "}\n";

    static final String FS_COPY =
            "#version 300 es\n" +
            "#extension GL_OES_EGL_image_external_essl3 : require\n" +
            "precision mediump float;\n" +
            "uniform samplerExternalOES uTex;\n" +
            "uniform mat4 uM;\n" +
            "in vec2 vUv;\n" +
            "out vec4 o;\n" +
            "void main(){\n" +
            "  vec2 uv = (uM * vec4(vUv, 0.0, 1.0)).xy;\n" +
            "  vec3 c = texture(uTex, uv).rgb;\n" +
            "  o = vec4(c, dot(c, vec3(0.299, 0.587, 0.114)));\n" +
            "}\n";

    static String fsUp(boolean ext) {
        return "#version 300 es\n" +
                (ext ? "#extension GL_OES_EGL_image_external_essl3 : require\n" : "") +
                "precision mediump float;\n" +
                "uniform " + (ext ? "samplerExternalOES" : "sampler2D") + " uTex;\n" +
                (ext ? "uniform mat4 uM;\n" : "") +
                "uniform vec2 uTexel;\n" +
                "uniform float uSharp;\n" +
                "in vec2 vUv;\n" +
                "out vec4 o;\n" +
                "vec3 f(vec2 p){ return texture(uTex, " + (ext ? "(uM * vec4(p, 0.0, 1.0)).xy" : "p") + ").rgb; }\n" +
                "void main(){\n" +
                "  vec3 c = f(vUv);\n" +
                "  if (uSharp <= 0.0) { o = vec4(c, 1.0); return; }\n" +
                "  vec3 n = f(vUv + vec2(0.0, uTexel.y));\n" +
                "  vec3 s = f(vUv - vec2(0.0, uTexel.y));\n" +
                "  vec3 e = f(vUv + vec2(uTexel.x, 0.0));\n" +
                "  vec3 w = f(vUv - vec2(uTexel.x, 0.0));\n" +
                "  vec3 blur = (n + s + e + w) * 0.25;\n" +
                "  o = vec4(clamp(c + uSharp * (c - blur), 0.0, 1.0), 1.0);\n" +
                "}\n";
    }

    // Busca em 3 passos (4,2,1 => +-7 px), 9 amostras de luminancia (alpha) por candidato,
    // e saida antecipada em blocos parados (HUD, ceu, etc).
    static final String FS_ME =
            "#version 300 es\n" +
            "precision highp int;\n" +
            "precision mediump float;\n" +
            "uniform sampler2D uCur;\n" +
            "uniform sampler2D uPrev;\n" +
            "uniform int uBlk;\n" +
            "out vec4 o;\n" +
            "float cost(ivec2 org, ivec2 d, ivec2 sz){\n" +
            "  float s = 0.0;\n" +
            "  int st = max(uBlk / 3, 1);\n" +
            "  for (int y = 0; y < 3; y++) {\n" +
            "    for (int x = 0; x < 3; x++) {\n" +
            "      ivec2 q = org + ivec2(x, y) * st + st / 2;\n" +
            "      ivec2 a = clamp(q, ivec2(0), sz - 1);\n" +
            "      ivec2 b = clamp(q + d, ivec2(0), sz - 1);\n" +
            "      s += abs(texelFetch(uCur, a, 0).a - texelFetch(uPrev, b, 0).a);\n" +
            "    }\n" +
            "  }\n" +
            "  return s + 0.01 * length(vec2(d));\n" +
            "}\n" +
            "void main(){\n" +
            "  ivec2 sz = textureSize(uCur, 0);\n" +
            "  ivec2 org = ivec2(gl_FragCoord.xy) * uBlk;\n" +
            "  ivec2 best = ivec2(0);\n" +
            "  float bc = cost(org, best, sz);\n" +
            "  if (bc > 0.03) {\n" +
            "    for (int i = 0; i < 3; i++) {\n" +
            "      int stp = 4 >> i;\n" +
            "      ivec2 c0 = best;\n" +
            "      for (int y = -1; y <= 1; y++) {\n" +
            "        for (int x = -1; x <= 1; x++) {\n" +
            "          if (x == 0 && y == 0) continue;\n" +
            "          ivec2 d = c0 + ivec2(x, y) * stp;\n" +
            "          float c = cost(org, d, sz);\n" +
            "          if (c < bc) { bc = c; best = d; }\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "  o = vec4((vec2(best) + 16.0) / 32.0, 0.0, 1.0);\n" +
            "}\n";

    static final String FS_INT =
            "#version 300 es\n" +
            "precision highp float;\n" +
            "uniform sampler2D uCur;\n" +
            "uniform sampler2D uPrev;\n" +
            "uniform sampler2D uMot;\n" +
            "uniform int uBlk;\n" +
            "out vec4 o;\n" +
            "vec2 mv(ivec2 g){\n" +
            "  ivec2 gs = textureSize(uMot, 0);\n" +
            "  g = clamp(g, ivec2(0), gs - 1);\n" +
            "  return texelFetch(uMot, g, 0).rg * 32.0 - 16.0;\n" +
            "}\n" +
            "void main(){\n" +
            "  vec2 sz = vec2(textureSize(uCur, 0));\n" +
            "  vec2 p = gl_FragCoord.xy;\n" +
            "  vec2 g = p / float(uBlk) - 0.5;\n" +
            "  ivec2 g0 = ivec2(floor(g));\n" +
            "  vec2 f = g - vec2(g0);\n" +
            "  vec2 d = mix(mix(mv(g0), mv(g0 + ivec2(1, 0)), f.x),\n" +
            "               mix(mv(g0 + ivec2(0, 1)), mv(g0 + ivec2(1, 1)), f.x), f.y);\n" +
            "  vec3 a = texture(uPrev, (p + 0.5 * d) / sz).rgb;\n" +
            "  vec3 b = texture(uCur, (p - 0.5 * d) / sz).rgb;\n" +
            "  vec3 plain = 0.5 * (texture(uPrev, p / sz).rgb + texture(uCur, p / sz).rgb);\n" +
            "  float err = dot(abs(a - b), vec3(0.3333));\n" +
            "  float t = clamp((err - 0.04) / 0.12, 0.0, 1.0);\n" +
            "  o = vec4(mix(0.5 * (a + b), plain, t), 1.0);\n" +
            "}\n";

    final MediaProjection proj;
    volatile int capW, capH;
    final int dpi;
    final float sharp;
    final float scale;
    final WindowManager wm;
    volatile boolean fg;
    volatile boolean newFrame, released;
    GLSurfaceView view;
    Runnable onFail;

    boolean pendingReal;
    int viewW, viewH, gw, gh, cur, frames;
    int extTex;
    final int[] tex = new int[2];
    final int[] fbo = new int[2];
    int texMid, fboMid, texMot, fboMot;
    int pCopy, pUp, pUpExt, pME, pInt;
    boolean haveExt;
    int copied;
    long lastNs;
    double emaDt;
    SurfaceTexture st;
    Surface surface;
    VirtualDisplay vd;
    final float[] tm = new float[16];

    Renderer(MediaProjection proj, WindowManager wm, float scale, int w, int h, int dpi, boolean fg, float sharp) {
        this.wm = wm;
        this.scale = scale;
        this.proj = proj;
        this.capW = w;
        this.capH = h;
        this.dpi = dpi;
        this.fg = fg;
        this.sharp = sharp;
    }

    void release() {
        released = true;
        try { if (vd != null) vd.release(); } catch (Throwable t) { }
        try { if (surface != null) surface.release(); } catch (Throwable t) { }
        try { if (st != null) st.release(); } catch (Throwable t) { }
    }

    static int sh(int type, String src) {
        int s = GLES30.glCreateShader(type);
        GLES30.glShaderSource(s, src);
        GLES30.glCompileShader(s);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("shader: " + GLES30.glGetShaderInfoLog(s));
        return s;
    }

    static int prog(String vs, String fs) {
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, sh(GLES30.GL_VERTEX_SHADER, vs));
        GLES30.glAttachShader(p, sh(GLES30.GL_FRAGMENT_SHADER, fs));
        GLES30.glLinkProgram(p);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("link: " + GLES30.glGetProgramInfoLog(p));
        return p;
    }

    static int makeTex(int w, int h) {
        int[] t = new int[1];
        GLES30.glGenTextures(1, t, 0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0]);
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, w, h, 0,
                GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        return t[0];
    }

    static int makeFbo(int tex) {
        int[] f = new int[1];
        GLES30.glGenFramebuffers(1, f, 0);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, f[0]);
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                GLES30.GL_TEXTURE_2D, tex, 0);
        return f[0];
    }

    static int loc(int p, String n) {
        return GLES30.glGetUniformLocation(p, n);
    }

    static void bindTex(int unit, int tex) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex);
    }

    static void draw() {
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
    }

    void alloc() {
        gw = (capW + BLK - 1) / BLK;
        gh = (capH + BLK - 1) / BLK;
        for (int i = 0; i < 2; i++) {
            tex[i] = makeTex(capW, capH);
            fbo[i] = makeFbo(tex[i]);
        }
        texMid = makeTex(capW, capH);
        fboMid = makeFbo(texMid);
        texMot = makeTex(gw, gh);
        fboMot = makeFbo(texMot);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
    }

    void free() {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        GLES30.glDeleteFramebuffers(2, fbo, 0);
        GLES30.glDeleteFramebuffers(1, new int[]{fboMid}, 0);
        GLES30.glDeleteFramebuffers(1, new int[]{fboMot}, 0);
        GLES30.glDeleteTextures(2, tex, 0);
        GLES30.glDeleteTextures(1, new int[]{texMid}, 0);
        GLES30.glDeleteTextures(1, new int[]{texMot}, 0);
    }

    // Roda na thread GL. Recalcula o tamanho da captura a partir do tamanho REAL da tela
    // (corrige o bug de captura retrato / tela paisagem apos girar).
    void resizeNow(int w, int h) {
        if (released || vd == null || (w == capW && h == capH)) return;
        try {
            free();
            capW = w;
            capH = h;
            alloc();
            st.setDefaultBufferSize(w, h);
            vd.resize(w, h, dpi);
            copied = 0;
            pendingReal = false;
        } catch (Throwable e) {
            Log.e(TAG, "resize falhou", e);
        }
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        try {
            try { Process.setThreadPriority(-8); } catch (Throwable t) {
                try { Process.setThreadPriority(-4); } catch (Throwable t2) { }
            }
            copied = 0;
            cur = 0;
            pendingReal = false;
            haveExt = false;
            newFrame = false;
            pCopy = prog(VS, FS_COPY);
            pUp = prog(VS, fsUp(false));
            pUpExt = prog(VS, fsUp(true));
            pME = prog(VS, FS_ME);
            pInt = prog(VS, FS_INT);
            alloc();

            int[] t = new int[1];
            GLES30.glGenTextures(1, t, 0);
            extTex = t[0];
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, extTex);
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);

            SurfaceTexture oldSt = st;
            Surface oldSurface = surface;
            st = new SurfaceTexture(extTex);
            st.setDefaultBufferSize(capW, capH);
            st.setOnFrameAvailableListener(new SurfaceTexture.OnFrameAvailableListener() {
                @Override
                public void onFrameAvailable(SurfaceTexture s) {
                    newFrame = true;
                    GLSurfaceView v = view;
                    if (v != null) v.requestRender();
                }
            });
            surface = new Surface(st);
            if (vd == null) {
                vd = proj.createVirtualDisplay("DuckScale", capW, capH, dpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null);
            } else {
                // Android 14+ nao permite recriar o VirtualDisplay: so troca a Surface
                vd.setSurface(surface);
                vd.resize(capW, capH, dpi);
            }
            try { if (oldSurface != null) oldSurface.release(); } catch (Throwable ign) { }
            try { if (oldSt != null) oldSt.release(); } catch (Throwable ign) { }
        } catch (Throwable e) {
            Log.e(TAG, "init falhou", e);
            released = true;
            if (onFail != null) onFail.run();
        }
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        viewW = w;
        viewH = h;
        try {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            int nw = Math.max(2, ((int) (dm.widthPixels * scale)) & ~1);
            int nh = Math.max(2, ((int) (dm.heightPixels * scale)) & ~1);
            resizeNow(nw, nh);
        } catch (Throwable t) {
            Log.e(TAG, "onSurfaceChanged", t);
        }
    }

    // Caminho rapido (sem frame generation): textura externa direto na tela, 1 passada
    void drawScreenExt() {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        GLES30.glViewport(0, 0, viewW, viewH);
        GLES30.glUseProgram(pUpExt);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, extTex);
        GLES30.glUniform1i(loc(pUpExt, "uTex"), 0);
        GLES30.glUniformMatrix4fv(loc(pUpExt, "uM"), 1, false, tm, 0);
        GLES30.glUniform2f(loc(pUpExt, "uTexel"), 1f / capW, 1f / capH);
        GLES30.glUniform1f(loc(pUpExt, "uSharp"), sharp);
        draw();
    }

    void drawScreen(int tex) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        GLES30.glViewport(0, 0, viewW, viewH);
        GLES30.glUseProgram(pUp);
        bindTex(0, tex);
        GLES30.glUniform1i(loc(pUp, "uTex"), 0);
        GLES30.glUniform2f(loc(pUp, "uTexel"), 1f / capW, 1f / capH);
        GLES30.glUniform1f(loc(pUp, "uSharp"), sharp);
        draw();
    }

    void interpolate() {
        int prev = cur ^ 1;
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboMot);
        GLES30.glViewport(0, 0, gw, gh);
        GLES30.glUseProgram(pME);
        bindTex(0, tex[cur]);
        bindTex(1, tex[prev]);
        GLES30.glUniform1i(loc(pME, "uCur"), 0);
        GLES30.glUniform1i(loc(pME, "uPrev"), 1);
        GLES30.glUniform1i(loc(pME, "uBlk"), BLK);
        draw();
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboMid);
        GLES30.glViewport(0, 0, capW, capH);
        GLES30.glUseProgram(pInt);
        bindTex(0, tex[cur]);
        bindTex(1, tex[prev]);
        bindTex(2, texMot);
        GLES30.glUniform1i(loc(pInt, "uCur"), 0);
        GLES30.glUniform1i(loc(pInt, "uPrev"), 1);
        GLES30.glUniform1i(loc(pInt, "uMot"), 2);
        GLES30.glUniform1i(loc(pInt, "uBlk"), BLK);
        draw();
        drawScreen(texMid);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        if (released) return;
        try {
            boolean nf = newFrame;
            newFrame = false;
            if (nf) {
                st.updateTexImage();
                st.getTransformMatrix(tm);
                haveExt = true;
                long now = System.nanoTime();
                if (lastNs != 0) {
                    double dt = (now - lastNs) / 1e9;
                    if (dt < 0.2) emaDt = (emaDt == 0) ? dt : emaDt * 0.8 + dt * 0.2;
                }
                lastNs = now;
            }
            if (!haveExt) return;

            if (!fg) {  // sem frame generation: caminho mais leve
                copied = 0;
                pendingReal = false;
                drawScreenExt();
                return;
            }

            if (nf) {
                int nxt = cur ^ 1;
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[nxt]);
                GLES30.glViewport(0, 0, capW, capH);
                GLES30.glUseProgram(pCopy);
                GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
                GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, extTex);
                GLES30.glUniform1i(loc(pCopy, "uTex"), 0);
                GLES30.glUniformMatrix4fv(loc(pCopy, "uM"), 1, false, tm, 0);
                draw();
                cur = nxt;
                copied++;
                // so interpola quando o jogo esta abaixo de ~50 FPS
                if (copied >= 2 && !pendingReal && emaDt > 0.020) {
                    interpolate();
                    pendingReal = true;
                    if (view != null) view.requestRender();
                    return;
                }
            }
            if (copied > 0) {
                drawScreen(tex[cur]);
                pendingReal = false;
            } else {
                drawScreenExt();
            }
        } catch (Throwable e) {
            if (!released) Log.e(TAG, "draw falhou", e);
        }
    }
}
