package com.duckscale;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.media.projection.MediaProjection;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;

public class ScalerService extends AccessibilityService {
    static ScalerService instance;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private GLSurfaceView view;
    private TextView stopBtn;
    private Renderer renderer;
    private MediaProjection proj;
    private float scale = 0.75f;

    @Override
    protected void onServiceConnected() {
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent i) {
        stopScaling();
        instance = null;
        return super.onUnbind(i);
    }

    boolean isRunning() {
        return view != null;
    }

    void setFrameGen(boolean on) {
        if (renderer != null) renderer.fg = on;
    }

    void startScaling(MediaProjection p, boolean fg, float sharp, float scale) {
        stopScaling();
        this.scale = scale;
        proj = p;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);

        proj.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopScaling();
            }
        }, main);

        int[] cs = capSize(dm);
        renderer = new Renderer(proj, wm, scale, cs[0], cs[1], dm.densityDpi, fg, sharp);
        renderer.onFail = new Runnable() {
            public void run() {
                main.post(new Runnable() {
                    public void run() {
                        stopScaling();
                    }
                });
            }
        };

        view = new GLSurfaceView(this);
        view.setEGLContextClientVersion(3);
        view.setEGLConfigChooser(8, 8, 8, 0, 0, 0);
        view.setZOrderOnTop(true);
        view.getHolder().setFormat(PixelFormat.OPAQUE);
        renderer.view = view;
        view.setRenderer(renderer);
        view.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.OPAQUE);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        // cobre a tela inteira, inclusive area do notch (API 28+, via reflexao p/ compilar com API 23)
        try {
            WindowManager.LayoutParams.class.getField("layoutInDisplayCutoutMode").setInt(lp, 1);
        } catch (Throwable t) {
        }
        view.setPreserveEGLContextOnPause(true);
        wm.addView(view, lp);

        stopBtn = new TextView(this);
        stopBtn.setText("\u25A0");
        stopBtn.setTextColor(0xFFFFFFFF);
        stopBtn.setTextSize(18);
        stopBtn.setBackgroundColor(0x66000000);
        stopBtn.setPadding(30, 14, 30, 14);
        stopBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                stopScaling();
            }
        });
        WindowManager.LayoutParams lp2 = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp2.gravity = Gravity.TOP | Gravity.RIGHT;
        wm.addView(stopBtn, lp2);
    }

    int[] capSize(DisplayMetrics dm) {
        return new int[]{Math.max(2, ((int) (dm.widthPixels * scale)) & ~1),
                Math.max(2, ((int) (dm.heightPixels * scale)) & ~1)};
    }

    void stopScaling() {
        GLSurfaceView v = view;
        TextView sb = stopBtn;
        Renderer r = renderer;
        MediaProjection p = proj;
        view = null;
        stopBtn = null;
        renderer = null;
        proj = null;
        if (r != null) r.release();
        if (p != null) {
            try {
                p.stop();
            } catch (Throwable t) {
            }
        }
        try {
            if (sb != null) wm.removeView(sb);
        } catch (Throwable t) {
        }
        try {
            if (v != null) wm.removeView(v);
        } catch (Throwable t) {
        }
    }
}
