package com.duckscale;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final int REQ = 1;
    TextView status;
    CheckBox cbFg;
    RadioGroup rg;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("DuckScale");
        title.setTextSize(26);
        l.addView(title);

        status = new TextView(this);
        status.setPadding(0, pad / 2, 0, pad / 2);
        l.addView(status);

        Button b1 = new Button(this);
        b1.setText("1. Ativar serviço (Acessibilidade)");
        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        l.addView(b1);

        cbFg = new CheckBox(this);
        cbFg.setText("Frame generation");
        cbFg.setChecked(true);
        cbFg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (ScalerService.instance != null) ScalerService.instance.setFrameGen(cbFg.isChecked());
            }
        });
        l.addView(cbFg);

        TextView q = new TextView(this);
        q.setText("Resolução da captura (menor = mais FPS)");
        q.setPadding(0, pad / 2, 0, 0);
        l.addView(q);
        rg = new RadioGroup(this);
        rg.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"100%", "75%", "50%"};
        for (int i = 0; i < 3; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(101 + i);
            rg.addView(rb);
        }
        rg.check(102);
        l.addView(rg);

        Button b2 = new Button(this);
        b2.setText("2. Iniciar");
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (ScalerService.instance == null) {
                    Toast.makeText(MainActivity.this, "Ative o serviço primeiro", Toast.LENGTH_LONG).show();
                    return;
                }
                MediaProjectionManager m = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                startActivityForResult(m.createScreenCaptureIntent(), REQ);
            }
        });
        l.addView(b2);

        Button b3 = new Button(this);
        b3.setText("Parar");
        b3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (ScalerService.instance != null) ScalerService.instance.stopScaling();
                refresh();
            }
        });
        l.addView(b3);

        TextView tip = new TextView(this);
        tip.setPadding(0, pad, 0, 0);
        tip.setText("No Android 14+, na janela de compartilhamento escolha \"Um único app\" e selecione o jogo. "
                + "Depois abra o jogo. O botão ■ no canto superior direito para tudo.");
        l.addView(tip);

        setContentView(l);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    void refresh() {
        ScalerService s = ScalerService.instance;
        if (s == null) status.setText("Serviço desativado. Toque em 1.");
        else if (s.isRunning()) status.setText("Escalando.");
        else status.setText("Pronto. Toque em 2.");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ || res != RESULT_OK || data == null) return;
        ScalerService s = ScalerService.instance;
        if (s == null) return;
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        MediaProjection p = m.getMediaProjection(res, data);
        int id = rg.getCheckedRadioButtonId();
        float scale = id == 101 ? 1.0f : (id == 103 ? 0.5f : 0.75f);
        s.startScaling(p, cbFg.isChecked(), scale >= 1.0f ? 0f : 0.35f, scale);
        moveTaskToBack(true);
    }
}
