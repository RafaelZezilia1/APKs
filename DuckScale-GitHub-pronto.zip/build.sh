#!/bin/bash
# Requer: JDK 11+ e Android SDK (platforms;android-34 e build-tools). Uso: ./build.sh
set -e
SDK=${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/lib/android-sdk}}
BT=$(ls -d "$SDK"/build-tools/* | sort -V | tail -1)
AJ=${ANDROID_JAR:-$(ls -d "$SDK"/platforms/android-* | sort -V | tail -1)/android.jar}
rm -rf classes classes.dex *.apk && mkdir classes
javac -source 8 -target 8 -bootclasspath "$AJ" -d classes src/com/duckscale/*.java
"$BT/d8" --min-api 24 --lib "$AJ" --output . $(find classes -name '*.class')
"$BT/aapt" package -f -M AndroidManifest.xml -S res -I "$AJ" -F app.unsigned.apk
"$BT/aapt" add app.unsigned.apk classes.dex
"$BT/zipalign" -f 4 app.unsigned.apk app.aligned.apk
[ -f debug.keystore ] || keytool -genkeypair -keystore debug.keystore -storepass android -alias key -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=DuckScale"
"$BT/apksigner" sign --ks debug.keystore --ks-pass pass:android --key-pass pass:android --out DuckScale.apk app.aligned.apk
echo "OK: DuckScale.apk"
