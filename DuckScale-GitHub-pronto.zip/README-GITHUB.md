# DuckScale — build do APK pelo GitHub

Este projeto pode gerar `DuckScale.apk` usando GitHub Actions, sem Android Studio no celular.

## Passos pelo celular

1. Entre em https://github.com e faça login.
2. Toque no `+` e escolha **New repository**.
3. Nome: `DuckScale`; marque **Public** (ou Private, se preferir) e crie o repositório.
4. No repositório, use **Add file → Upload files**.
5. Extraia este ZIP no celular antes de enviar e envie o CONTEÚDO da pasta (incluindo `src`, `res`, `AndroidManifest.xml`, `build.sh` e `.github`). Não envie apenas o ZIP compactado.
6. Toque em **Commit changes**.
7. Abra a aba **Actions**, selecione **Build APK** e aguarde terminar.
8. Abra a execução concluída e baixe o artefato **DuckScale-apk**. Dentro dele estará `DuckScale.apk`.

## Observações

- O workflow já está configurado em `.github/workflows/build.yml`.
- O APK é assinado com uma chave de debug gerada durante a compilação. É adequado para teste/instalação manual, não para publicação na Play Store.
- O app solicita ativação do serviço de Acessibilidade e captura de tela. Leia as permissões e confirme apenas se confiar no funcionamento do aplicativo.
